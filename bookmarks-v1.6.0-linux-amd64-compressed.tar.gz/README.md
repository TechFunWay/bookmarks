# 网址收藏夹

一个简单易用的网址收藏夹管理工具，基于Go语言后端和Vue.js前端构建。

![Bookmark Manager](bookmarks.png)

## 功能特性

- 📁 **文件夹管理** - 创建、编辑、删除文件夹，支持嵌套结构
- 🔖 **书签管理** - 添加、编辑、删除网址书签，支持批量操作
- 🔄 **拖拽排序** - 支持文件夹和书签的拖拽重排序
- 📦 **批量操作** - 批量选择、删除和移动书签
- 🌐 **元数据获取** - 自动获取网页标题和favicon图标
- 🎨 **现代化界面** - 简洁美观的用户界面
- 📱 **响应式设计** - 适配不同屏幕尺寸
- ⚡ **快速响应** - 基于SQLite本地数据库，查询速度快
- 🔒 **安全可靠** - 支持内网HTTPS站点访问
- 📤 **导入导出** - 支持JSON格式书签的导入和导出
- 🌐 **Edge浏览器支持** - 支持导入和导出Edge浏览器的HTML格式书签
- 🎨 **主题切换** - 支持浅色和深色主题切换
- 🎨 **背景设置** - 支持自定义背景（默认、纯色、图片），可调节面板透明度
- 📊 **每页显示** - 支持自定义每行显示的书签数量（1-6个）
- 🔍 **搜索功能** - 支持按网址名称搜索书签
- 💾 **配置保存** - 所有设置自动保存到数据库，跨浏览器同步

## 技术架构

### 后端技术栈
- **Go 1.21+** - 主要编程语言
- **Chi** - 轻量级HTTP路由器
- **SQLite** - 本地数据库存储
- **Go Modules** - 依赖管理

### 前端技术栈
- **Vue.js 3** - 现代JavaScript框架
- **HTML5/CSS3** - 页面布局和样式
- **Fetch API** - HTTP请求处理

### 数据存储
- SQLite数据库文件：`data.db`
- 支持外键约束和数据一致性
- 自动维护排序位置

## 快速开始

### 系统要求
- Go 1.21 或更高版本
- 支持SQLite的操作系统（Windows/macOS/Linux）
- Docker（可选，用于容器化部署）

### 安装步骤

#### 方式一：直接运行

1. **克隆或下载项目**
   ```bash
   git clone <项目地址>
   cd bookmarks
   ```

2. **运行应用**
   - 使用默认端口8901启动：
   ```bash
   go run main.go
   ```

   - 自定义端口启动：
   ```bash
   go run main.go -port 3000
   ```

   - 自定义数据路径和端口：
   ```bash
   go run main.go -dataUrl /path/to/data -port 8080
   ```

3. **访问应用**
   - 默认访问地址：http://localhost:8901
   - 或访问您指定的端口地址
   - 查看所有可用选项：`go run main.go -h`

#### 方式二：Docker部署（推荐）

**快速启动（推荐新手使用）：**

Linux/macOS用户：
```bash
cd docker
./start.sh
```

Windows用户：
```cmd
cd docker
start.bat
```

**详细使用指南：**

请查看 [docker/README.md](docker/README.md) 获取完整的Docker部署指南，包括：
- 快速启动
- 自定义端口
- 手动构建和运行
- 常用命令
- 故障排除

**手动启动：**

1. **使用docker-compose快速启动**
   ```bash
   cd docker
   docker-compose up -d
   ```
   应用将在默认端口8901上运行，访问地址：http://localhost:8901

2. **自定义端口启动**
   ```bash
   # 方法1：修改docker-compose.yml中的PORT环境变量
   # 然后运行
   cd docker
   docker-compose up -d

   # 方法2：命令行指定端口（例如使用8080端口）
   cd docker
   PORT=8080 docker-compose up -d
   ```

3. **手动构建和运行**
   ```bash
   # AMD64架构
   docker build -f docker/Dockerfile.amd64 -t bookmarks:amd64 .
   docker run -d -p 8901:8901 -v $(pwd)/data:/app/data bookmarks:amd64

   # ARM64架构（如树莓派等）
   docker build -f docker/Dockerfile.arm64 -t bookmarks:arm64 .
   docker run -d -p 8901:8901 -v $(pwd)/data:/app/data bookmarks:arm64
   ```

4. **使用自定义端口运行**
   ```bash
   # 映射到8080端口
   docker run -d -p 8080:8901 -v $(pwd)/data:/app/data bookmarks:amd64

   # 映射到3000端口
   docker run -d -p 3000:8901 -v $(pwd)/data:/app/data bookmarks:amd64
   ```

5. **停止和删除容器**
   ```bash
   cd docker
   
   # 停止容器
   docker-compose down

   # 停止并删除数据卷
   docker-compose down -v
   ```

### Docker数据持久化

应用的数据（SQLite数据库）默认存储在容器内的`/app/data`目录。为了防止数据丢失，建议使用Docker volume或绑定挂载：

- **docker-compose方式**：已自动配置`../data:/app/data`挂载，数据会保存在宿主机的`./data`目录（相对于项目根目录）
- **docker run方式**：使用`-v $(pwd)/data:/app/data`参数挂载

### Docker常用命令

```bash
# 查看容器日志
cd docker
docker-compose logs -f bookmarks

# 查看容器状态
cd docker
docker-compose ps

# 重启容器
cd docker
docker-compose restart

# 进入容器
docker exec -it bookmarks sh

# 查看容器健康状态
docker inspect bookmarks | grep -A 10 Health
```

### 自定义配置

启动时可以通过命令行参数自定义配置：

#### 数据路径
```bash
go run main.go -dataUrl=/path/to/your/data/
```

#### 端口配置
```bash
go run main.go -port 3000
```

#### 组合配置
```bash
go run main.go -dataUrl=/path/to/data -port 8080
```

#### 查看所有选项
```bash
go run main.go -h
```

**可用参数：**
- `-dataUrl`：数据存储路径（默认："./"）
- `-port`：服务器监听端口（默认："8901"）

## 使用说明

### 基础操作

1. **创建文件夹**
   - 点击左侧"新建文件夹"按钮
   - 或右键点击现有文件夹选择"新建子文件夹"

2. **添加书签**
   - 点击左侧"添加网址"按钮
   - 或右键点击文件夹选择"添加网址"
   - 输入网址后点击"获取信息"可自动填充标题和图标

3. **编辑项目**
   - 双击文件夹或书签名称进行编辑
   - 或右键选择"编辑"选项

4. **删除项目**
   - 右键选择"删除"选项
   - 或在编辑模式下批量选择删除

### 高级功能

1. **重排序**
   - 拖拽文件夹或书签到新位置
   - 或使用右键菜单的"上移"/"下移"选项

2. **移动到文件夹**
   - 右键选择"移动到文件夹"
   - 选择目标文件夹并确认

3. **批量操作**
   - 点击"编辑"按钮进入编辑模式
   - 使用复选框选择多个项目
   - 执行批量删除或移动操作

4. **搜索和组织**
   - 通过文件夹结构组织书签
   - 查看书签路径信息
   - 使用搜索框按名称搜索书签

5. **导入导出**
   - 点击顶部的"导出"按钮导出JSON格式书签
   - 点击顶部的"导入"按钮导入JSON格式书签
   - 选择导入模式（合并或替换）
   - 选择导入目标文件夹
   - 支持从Edge浏览器导入HTML格式书签

6. **主题切换**
   - 点击右上角的主题切换按钮
   - 在浅色和深色主题之间切换
   - 主题设置会自动保存

7. **背景设置**
   - 点击右上角的"背景"按钮
   - 选择背景类型：默认背景、纯色背景、图片背景
   - 可以上传自定义图片作为背景
   - 支持调节面板透明度，让背景图片或颜色透过面板显示
   - 背景设置会自动保存

8. **每页显示设置**
   - 在网址列表上方选择每行显示的书签数量（1-6个）
   - 设置会自动保存到数据库
   - 换浏览器后设置依然有效

### 快捷操作

- **右键菜单**：在任何项目上右键查看可用操作
- **双击编辑**：双击项目名称快速编辑
- **拖拽移动**：直接拖拽到目标位置
- **批量选择**：使用编辑模式进行批量操作

## API接口

### RESTful API
- `GET /api/tree` - 获取完整树结构
- `GET /api/metadata?url=<网址>` - 获取网页元数据
- `POST /api/folders` - 创建文件夹
- `POST /api/bookmarks` - 创建书签
- `PUT /api/nodes/{id}` - 更新节点
- `DELETE /api/nodes/{id}` - 删除节点
- `POST /api/nodes/reorder` - 重新排序节点
- `POST /api/import` - 导入JSON格式书签
- `POST /api/import-edge` - 导入Edge浏览器HTML格式书签
- `GET /api/config` - 获取配置（主题、背景、每页显示等）
- `POST /api/config` - 保存配置（主题、背景、每页显示等）

### 请求示例

```bash
# 获取树结构
curl http://localhost:8901/api/tree

# 创建文件夹
curl -X POST http://localhost:8901/api/folders \
  -H "Content-Type: application/json" \
  -d '{"title":"工作相关","parent_id":null}'

# 创建书签
curl -X POST http://localhost:8901/api/bookmarks \
  -H "Content-Type: application/json" \
  -d '{"title":"GitHub","url":"https://github.com","parent_id":1}'
```

## 配置说明

### 数据库配置
- 数据库文件位置：可通过`-dataUrl`参数指定
- 默认位置：当前目录下的`data.db`
- 自动创建必要的表和索引

### 服务器配置
- 默认端口：8901
- 支持静态文件服务
- 内置CORS支持

## 目录结构

```
bookmarks/
├── main.go              # 主程序入口
├── go.mod               # Go模块定义
├── go.sum               # 依赖校验
├── data.db              # SQLite数据库文件（运行时生成）
├── static/              # 静态文件目录
│   ├── index.html       # 主页面
│   ├── app.js          # Vue.js应用
│   └── style.css       # 样式文件
├── README.md           # 中文说明
├── README.en.md        # English README
└── techfunway.bookmarks/ # 打包相关文件
```

## 开发说明

### 环境要求
- Go 1.21+
- 现代浏览器支持（Chrome、Firefox、Safari、Edge）

### 开发运行
```bash
# 启动开发服务器
go run main.go

# 修改前端代码后刷新浏览器即可看到效果
```

### 部署建议
- 可以打包成单文件可执行程序
- 支持在任何支持Go的平台上运行
- 数据文件可与程序分离，便于备份

## 故障排除

### 常见问题

1. **端口被占用**
   - 检查8901端口是否被其他程序占用
   - 或修改代码中的端口配置
   - Docker用户可以使用自定义端口：`docker run -p 8080:8901 ...`

2. **数据库错误**
   - 确保有写入权限
   - 检查磁盘空间是否充足

3. **网页元数据获取失败**
   - 检查网络连接
   - 某些网站可能限制爬虫访问

4. **HTTPS站点访问失败**
   - 应用支持自签名证书
   - 内网HTTPS站点可正常访问

5. **Docker容器无法启动**
   - 检查Docker是否正常运行：`docker ps`
   - 查看容器日志：`docker-compose logs -f bookmarks`
   - 确保端口未被占用
   - 检查数据目录权限

6. **Docker数据丢失**
   - 确保使用了volume挂载：`-v $(pwd)/data:/app/data`
   - 检查宿主机data目录是否有数据
   - 避免使用`docker-compose down -v`（会删除数据卷）

7. **Docker健康检查失败**
   - 等待容器完全启动（最多30秒）
   - 检查容器日志：`docker-compose logs bookmarks`
   - 确认应用正常运行

### 日志查看
- 启动时会显示服务器运行端口
- 浏览器开发者工具查看前端错误
- 服务器日志显示API请求和错误信息

## 许可证

本项目采用MIT许可证，详见LICENSE文件。

## 参与贡献

欢迎提交Issue和Pull Request！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 更新日志

### v1.4.0
- 新增背景设置功能，支持默认背景、纯色背景、自定义图片背景
- 新增面板透明度调节功能，可调节列表和结构面板的透明度
- 新增每页显示数量保存功能，设置自动保存到数据库，跨浏览器同步
- 优化浅色主题下选中数字的显示效果
- 调整PC端列表布局高度，解决内容超出问题
- 性能优化和bug修复

### v1.2.0
- 新增导入导出功能，支持JSON格式书签的导入和导出
- 新增Edge浏览器支持，支持导入和导出Edge浏览器的HTML格式书签
- 新增主题切换功能，支持浅色和深色主题切换
- 优化了文件夹选择功能，修复了导入时无法选择文件夹的问题
- 修复了交叉编译问题，支持生成不同架构的Linux二进制文件
- 性能优化和bug修复

### v1.1.0
- 新增搜索功能，支持按网址名称搜索
- 手机端适配优化
- 性能优化和bug修复

### v1.0.0
- 初始版本发布
- 基础文件夹和书签管理功能
- 拖拽排序支持
- 批量操作功能
- 网页元数据获取
- 响应式设计，适配不同屏幕尺寸
- 现代化美观界面
- 支持内网HTTPS站点访问

## 安全说明

### 数据安全
- 数据存储在本地SQLite数据库文件中，不会上传到云端
- 支持定期备份数据库文件
- 建议将数据文件存储在安全位置

### 网络安全
- 仅通过本地HTTP服务器访问，不暴露公网
- 支持内网HTTPS站点访问
- 无第三方依赖，减少安全风险

## 浏览器兼容性

- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+

## 性能优化

- 本地SQLite数据库，查询速度快
- 前端采用Vue.js 3，渲染性能优秀
- 支持大量书签和文件夹的高效管理
- 拖拽操作流畅，响应迅速

## 备份和恢复

### 备份数据
1. 关闭应用程序
2. 复制`data.db`文件到安全位置
3. 完成备份

### 恢复数据
1. 关闭应用程序
2. 将备份的`data.db`文件复制到应用程序目录
3. 启动应用程序
4. 数据将自动恢复

## 未来计划

- [ ] 支持标签功能
- [ ] 支持快捷键操作
- [ ] 支持书签预览功能
- [ ] 支持云同步功能
- [ ] 支持更多浏览器的书签导入导出
- [ ] 支持更高级的搜索功能
- [ ] 支持书签分组和智能分类
- [ ] 支持自定义主题和样式

## 支持和反馈

如果您在使用过程中遇到问题或有任何建议，欢迎通过以下方式反馈：

- 创建Issue：在GitHub仓库提交Issue
- 邮件反馈：发送邮件到[your-email@example.com]
- 提交Pull Request：贡献代码或改进

## 致谢

感谢所有为本项目做出贡献的开发者和用户！

## 关于作者

一个热爱技术的开发者，致力于创建简单易用的工具，提高工作效率。
